Adding `build_flags = -DROUTINES_API_ENABLE_DEBUG_LOGS` should enable debug logging.
